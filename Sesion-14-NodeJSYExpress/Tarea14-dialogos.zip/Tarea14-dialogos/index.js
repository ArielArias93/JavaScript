const boton = document.querySelector(".btn")


boton.addEventListener("click", () => {

    alert("Se ha hecho click!")

})

$(".btn").click(() =>{

    console.log("Hola estoy usando JQuery");


})